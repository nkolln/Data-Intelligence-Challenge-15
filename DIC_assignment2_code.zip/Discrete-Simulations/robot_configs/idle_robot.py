# Very boring robot that does nothing:
def robot_epoch(robot):
    pass
